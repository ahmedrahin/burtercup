<!DOCTYPE html>
<html>
<head>
    <title>Your OTP Code</title>
</head>
<body>
<p>Dear User,</p>
<p>Your OTP code is: <strong style="color: #076f99;font-weight: 700;">{{ $otp }}</strong></p>
<p>This code is valid for 30 minutes. Please use it to complete your verification.</p>
<p>Thank you!</p>
</body>
</html>
