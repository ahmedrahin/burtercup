<div class="bottom-page">
    <div class="body-text">Copyright © 2025.</div>

</div>
