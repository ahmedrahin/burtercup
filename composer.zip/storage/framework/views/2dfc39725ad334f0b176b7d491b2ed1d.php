<!-- Javascript -->
<script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/bootstrap-select.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/zoom.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/apexcharts/apexcharts.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/apexcharts/line-chart-1.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/apexcharts/line-chart-2.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/apexcharts/line-chart-3.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/apexcharts/line-chart-4.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/apexcharts/line-chart-5.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/apexcharts/line-chart-6.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/switcher.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/theme-settings.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
<script src="<?php echo e(asset('assets/js/dropify.min.js')); ?>"></script>


<script src="<?php echo e(asset('assets/js/toastify.js')); ?>"></script>
<?php if(session('success') || session('error') || session('info') || session('warning')): ?>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        let message = "<?php echo e(session('success') ?? session('error') ?? session('info') ?? session('warning')); ?>";
        let type = "<?php echo e(session('success') ? 'success' : (session('error') ? 'error' : (session('info') ? 'info' : 'warning'))); ?>";

        let iconHtml = "";
        switch (type) {
            case "success":
                iconHtml = '<i class="bi bi-check-circle-fill" style="color: #28a745; font-size: 18px;"></i>';
                break;
            case "error":
                iconHtml = '<i class="bi bi-x-circle-fill" style="color: #e74c3c; font-size: 18px;"></i>';
                break;
            case "info":
                iconHtml = '<i class="bi bi-info-circle-fill" style="color: #3498db; font-size: 18px;"></i>';
                break;
            case "warning":
                iconHtml = '<i class="bi bi-exclamation-circle-fill" style="color: #f39c12; font-size: 18px;"></i>';
                break;
            default:
                iconHtml = "";
        }

        Toastify({
            text: `<span>
                    <span style="margin-right: 6px; font-size: 18px;">${iconHtml}</span>
                    <span>${message}</span>
                </span>`,
            duration: 3000,
            gravity: "bottom",
            position: "left",
            close: true,
            escapeMarkup: false,
            style: {
                background: "#fff",
                color: "#000",
                boxShadow: "0px 4px 10px rgba(0,0,0,0.1)",
                borderRadius: "8px",
                padding: "20px 15px",
                fontSize: "16px",
                fontWeight: '600',
                border: "2px solid #ddd",
                marginBottom: "5px",
                bottom: "100px",
                marginBottom: "30px",
            }
        }).showToast();
    });
</script>
<?php endif; ?>


<script>
    function ajaxMessage(message, type){
        let iconHtml = "";
        switch (type) {
            case "success":
                iconHtml = '<i class="bi bi-check-circle-fill" style="color: #28a745; font-size: 18px;"></i>';
                break;
            case "error":
                iconHtml = '<i class="bi bi-x-circle-fill" style="color: #e74c3c; font-size: 18px;"></i>';
                break;
            case "info":
                iconHtml = '<i class="bi bi-info-circle-fill" style="color: #3498db; font-size: 18px;"></i>';
                break;
            case "warning":
                iconHtml = '<i class="bi bi-exclamation-circle-fill" style="color: #f39c12; font-size: 18px;"></i>';
                break;
            default:
                iconHtml = "";
        }

        Toastify({
            text: `<span>
                    <span style="margin-right: 6px; font-size: 18px;">${iconHtml}</span>
                    <span>${message}</span>
                </span>`,
            duration: 3000,
            gravity: "bottom",
            position: "left",
            close: true,
            escapeMarkup: false,
            style: {
                background: "#fff",
                color: "#000",
                boxShadow: "0px 4px 10px rgba(0,0,0,0.1)",
                borderRadius: "8px",
                padding: "20px 15px",
                fontSize: "16px",
                fontWeight: '600',
                border: "2px solid #ddd",
                marginBottom: "5px",
                bottom: "100px",
                marginBottom: "30px",
            }
        }).showToast();
    }
</script>

<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
</script>


<?php echo $__env->yieldPushContent('scripts'); ?>
<?php /**PATH C:\Users\USER\Herd\azad\resources\views/backend/partials/scripts.blade.php ENDPATH**/ ?>