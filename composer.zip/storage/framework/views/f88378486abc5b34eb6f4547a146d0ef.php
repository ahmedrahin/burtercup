<div class="section-menu-left">
    <div class="box-logo">
        <a href="<?php echo e(route('dashboard')); ?>" id="site-logo-inner">
            <img class="" id="logo_header" alt="" src="<?php echo e(asset($system_settings->logo)); ?>" data-light="<?php echo e(asset($system_settings->logo)); ?>" data-dark="<?php echo e(asset($system_settings->dark_logo)); ?>" >
        </a>
        <div class="button-show-hide">
            <i class="icon-menu-left"></i>
        </div>
    </div>
    <div class="section-menu-left-wrap">
        <div class="center">
            <div class="center-item">
                <ul class="menu-list">
                    <li class="menu-item <?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('dashboard')); ?>" class="menu-item-button">
                            <div class="icon">
                                <i class="icon-grid"></i>
                            </div>
                            <div class="text">Dashboard</div>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="center-item">
                <div class="center-heading">Admin Management</div>
                <ul class="menu-list">
                    <li class="menu-item has-children <?php echo e(request()->routeIs('admin*') ? 'active' : ''); ?>">
                        <a href="javascript:void(0);" class="menu-item-button">
                            <div class="icon"><i class="icon-user-check"></i></div>
                            <div class="text">Admin Details</div>
                        </a>
                        <ul class="sub-menu">
                            <li class="sub-menu-item">
                                <a href="<?php echo e(route('admin.index')); ?>" class="<?php echo e(request()->routeIs('admin.index') ? 'active' : ''); ?>">
                                    <div class="text">Admin List</div>
                                </a>
                            </li>
                            <li class="sub-menu-item">
                                <a href="<?php echo e(route('admin.create')); ?>" class="<?php echo e(request()->routeIs('admin.create') ? 'active' : ''); ?>">
                                    <div class="text">Create new Admin</div>
                                </a>
                            </li>
                        </ul>
                    </li>

                    <div class="center-heading" style="margin-top: 15px;">User Management</div>
                    <ul class="menu-list">
                        <li class="menu-item">
                            <a href="<?php echo e(route('user.index')); ?>" class="<?php echo e(request()->routeIs('user.index') ? 'active' : ''); ?>" style="padding-bottom: 5px;">
                                <div class="icon"><i class="icon-user-plus"></i></div>
                                <div class="text">Register User</div>
                            </a>
                        </li>
                    </ul>

                    <ul class="menu-list">
                        <li class="menu-item">
                            <a href="<?php echo e(route('user.message')); ?>" class="<?php echo e(request()->routeIs('user.message') ? 'active' : ''); ?>">
                                <div class="icon"><i class="icon-mail"></i></div>
                                <div class="text">User Messages</div>
                            </a>
                        </li>
                    </ul>


                    


                    <div class="center-heading" style="margin-top: 15px;">PRODUCT Management</div>
                     <ul class="menu-list">
                        <li class="menu-item">
                            <a href="<?php echo e(route('attribute.index')); ?>" class="<?php echo e(request()->routeIs('attribute*') ? 'active' : ''); ?>">
                                <div class="icon"><i class="icon-tag"></i></div>
                                <div class="text">Product Attribute</div>
                            </a>
                        </li>
                    </ul>

                    <li class="menu-item has-children <?php echo e(request()->routeIs('product*') ? 'active' : ''); ?>">
                        <a href="javascript:void(0);" class="menu-item-button">
                            <div class="icon"><i class="icon-gift"></i></div>
                            <div class="text">Products</div>
                        </a>
                        <ul class="sub-menu">
                            <li class="sub-menu-item">
                                <a href="<?php echo e(route('product.index')); ?>" class="<?php echo e(request()->routeIs('product.index') ? 'active' : ''); ?>">
                                    <div class="text">All Product</div>
                                </a>
                            </li>
                            <li class="sub-menu-item">
                                <a href="<?php echo e(route('product.create')); ?>" class="<?php echo e(request()->routeIs('product.create') ? 'active' : ''); ?>">
                                    <div class="text">Add new product</div>
                                </a>
                            </li>
                        </ul>
                    </li>


                    <div class="center-heading" style="margin-top: 15px;">System Settings</div>
                    <li class="menu-item has-children <?php echo e(request()->routeIs('system-setting*') ? 'active' : ''); ?>">
                        <a href="javascript:void(0);" class="menu-item-button">
                            <div class="icon"><i class="icon-settings"></i></div>
                            <div class="text">Settings</div>
                        </a>
                        <ul class="sub-menu">
                            <li class="sub-menu-item">
                                <a href="<?php echo e(route('system-setting.index')); ?>" class="<?php echo e(request()->routeIs('system-setting.index') ? 'active' : ''); ?>">
                                    <div class="text">System Settings</div>
                                </a>
                            </li>
                            <li class="sub-menu-item">
                                <a href="<?php echo e(route('sociallink-setting.index')); ?>" class="<?php echo e(request()->routeIs('sociallink-setting.index') ? 'active' : ''); ?>">
                                    <div class="text">Social Link</div>
                                </a>
                            </li>
                        </ul>
                    </li>

                </ul>
            </div>

        </div>

    </div>
</div>
<?php /**PATH C:\Users\USER\Herd\burtercup\resources\views/backend/partials/sidebar.blade.php ENDPATH**/ ?>