<?php $__env->startSection('title', 'Product Details'); ?>

<?php $__env->startPush('styles'); ?>

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/swiper-bundle.min.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        .info-box {
            padding: 20px 0 0;
        }
        .info-box h4 {
            font-size: 16px;
            padding-bottom: 15px;
        }
        .info-box {
            font-size: 13px;
        }
        dd{
            color: black;
        }
        .infos {
            border-top: 1px solid #eee;
            border-bottom: 1px solid #eee;
        }
        .short-description p {
            line-height: 24px !important;
        }
        .variant-picker-item .variant-picker-values label{
            background-color: var(--Main);
            border-color: var(--Main) !important;
        }
        .body-title-2{
            color: white;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    <div class="main-content-wrap">
        <div class="flex items-center flex-wrap justify-between gap20 mb-27">
            <h3>Product Details</h3>
            <ul class="breadcrumbs flex items-center flex-wrap justify-start gap10">
                <li>
                    <a href="index.html"><div class="text-tiny">Dashboard</div></a>
                </li>
                <li>
                    <i class="icon-chevron-right"></i>
                </li>
                <li>
                    <a href="<?php echo e(route('product.index')); ?>"><div class="text-tiny">Product</div></a>
                </li>
                <li>
                    <i class="icon-chevron-right"></i>
                </li>
                <li>
                    <div class="text-tiny"><?php echo e($product->name); ?></div>
                </li>
            </ul>
        </div>


        <div class="wg-box">
            <div class="tf-main-product section-image-zoom flex">
                <div class="tf-product-media-wrap">
                    <div class="thumbs-slider">
                        <div class="swiper tf-product-media-thumbs other-image-zoom" data-direction="vertical">
                            <div class="swiper-wrapper">
                                <div class="swiper-slide">
                                    <div class="item">
                                        <img class="tf-image-zoom" data-zoom="" src="<?php echo e(asset($product->thumb_image)); ?>" alt="">
                                    </div>
                                </div>
                                <?php $__currentLoopData = $product->gellary_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="swiper-slide">
                                        <div class="item">
                                            <img src="<?php echo e(asset($image->image)); ?>" alt="">
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <div class="swiper tf-product-media-main" id="gallery-swiper-started">
                            <div class="swiper-wrapper" >
                                <div class="swiper-slide">
                                    <div class="item">
                                        <a href="images/products/product-detail-1.png" target="_blank" data-pswp-width="506px" data-pswp-height="810px">
                                            <img class="tf-image-zoom" data-zoom="<?php echo e(asset($product->thumb_image)); ?>" src="<?php echo e(asset($product->thumb_image)); ?>" alt="">
                                        </a>
                                    </div>
                                </div>
                                <?php $__currentLoopData = $product->gellary_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="swiper-slide">
                                        <div class="item">
                                            <a href="<?php echo e(asset($image->image)); ?>" target="_blank" data-pswp-width="500px" data-pswp-height="500px">
                                                <img class="tf-image-zoom" data-zoom="<?php echo e(asset($image->image)); ?>" src="<?php echo e(asset($image->image)); ?>" alt="">
                                            </a>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="swiper-button-next button-style-arrow thumbs-next"></div>
                            <div class="swiper-button-prev button-style-arrow thumbs-prev"></div>
                        </div>
                    </div>
                </div>


                <div class="tf-product-info-wrap relative flex-grow">
                    <div class="tf-zoom-main"></div>
                    <div class="tf-product-info-list other-image-zoom">
                        <div class="tf-product-info-title" style="margin-bottom: 25px;">
                            <h3><?php echo e($product->name); ?></h3>

                            <?php
                                $averageRating = round($product->reviews->avg('rating'), 1);
                                $fullStars = floor($averageRating);
                                $halfStar = ($averageRating - $fullStars) >= 0.5 ? 1 : 0;
                                $emptyStars = 5 - $fullStars - $halfStar;
                            ?>

                            <div class="d-flex align-items-center rating my-4">
                                <?php for($i = 0; $i < $fullStars; $i++): ?>
                                    <i class="bi bi-star-fill text-warning me-2"></i>
                                <?php endfor; ?>
                                <?php if($halfStar): ?>
                                    <i class="bi bi-star-half text-warning me-2"></i>
                                <?php endif; ?>
                                <?php for($i = 0; $i < $emptyStars; $i++): ?>
                                    <i class="bi bi-star text-muted me-2"></i>
                                <?php endfor; ?>
                                <span class="ms-2 text-muted">(<?php echo e($product->reviews->count()); ?> reviews)</span>
                            </div>

                            <div class="price body-title">
                                ৳<?php echo e($product->offer_price); ?>

                                <?php if( $product->discount_option != 1 ): ?>
                                    <span class="text-danger" style="font-weight: 600;">
                                        <del>৳<?php echo e(number_format($product->base_price, 2)); ?></del>
                                        <?php
                                            $discountPercentage = round((($product->discount_amount) / $product->base_price) * 100);
                                        ?>
                                        <?php echo e($discountPercentage); ?>% off
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="short-description" style="margin-bottom: 25px;">
                            <?php if( !is_null( $product->description)): ?>
                                <?php echo $product->description; ?>

                            <?php endif; ?>
                        </div>


                        <div class="row infos">
                            <div class="row info-box">
                                <div class="col-md-6">
                                    <div class="product-details">
                                        <h4>General Information</h4>
                                        <dl class="row mb-0">
                                            <dt class="col-sm-6">Sku code:</dt>
                                            <dd class="col-sm-6"><?php echo e($product->sku_code ?? 'N/A'); ?></dd>

                                            <dt class="col-sm-6">Category:</dt>
                                            <dd class="col-sm-6">
                                                <?php if($product->category): ?>
                                                    <?php echo $product->category->name; ?>

                                                    <?php if($product->subcategory): ?>
                                                        -> <?php echo $product->subcategory->name; ?>

                                                        <?php if($product->subsubcategory): ?>
                                                            -> <?php echo $product->subsubcategory->name; ?>

                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <span class="no">Uncategorized</span>
                                                <?php endif; ?>
                                            </dd>

                                            <dt class="col-sm-6">Brand:</dt>
                                            <dd class="col-sm-6"><?php echo e($product->brand->name ?? 'N/A'); ?></dd>

                                            <dt class="col-sm-6">Quantity:</dt>
                                            <dd class="col-sm-6">
                                                <?php if($product->quantity > 0): ?>
                                                    <span class="text-success"><?php echo e($product->quantity); ?> pcs</span>
                                                <?php else: ?>
                                                    <span class="text-danger p-0">Out of stock!</span>
                                                <?php endif; ?>
                                            </dd>
                                        </dl>
                                    </div>
                                </div>
                            </div>

                            <div class="row info-box">
                                <div class="col-md-6">
                                    <div class="product-details">
                                        <h4>Others Information</h4>
                                        <dl class="row">
                                            <dt class="col-sm-6">Created at:</dt>
                                            <dd class="col-sm-6"><?php echo e(\Carbon\Carbon::parse($product->created_at)->format('M-d-Y h:i A')); ?></dd>
                                            <dt class="col-sm-6">Last Updated:</dt>
                                            <dd class="col-sm-6">
                                                <?php if( $product->created_at != $product->updated_at ): ?>
                                                    <?php echo e(\Carbon\Carbon::parse($product->updated_at)->format('M-d-Y h:i A')); ?>

                                                <?php else: ?>
                                                    No update yet
                                                <?php endif; ?>
                                            </dd>
                                            <dt class="col-sm-6">Created by:</dt>
                                            <dd class="col-sm-6">
                                                <?php if( isset($product->user) ): ?>
                                                    <a href="<?php echo e(route('admin.show', optional($product->user)->id)); ?>" target="_blank">
                                                        <?php echo e(optional($product->user)->name ?? 'N/A'); ?>

                                                    </a>
                                                <?php endif; ?>
                                            </dd>
                                            <?php if( !is_null($product->expire_date) ): ?>
                                                <dt class="col-sm-6">Expire date:</dt>
                                                <dd class="col-sm-6 text-danger">
                                                    <?php if(\Carbon\Carbon::now()->lt($product->expire_date)): ?>
                                                        <?php echo e(\Carbon\Carbon::parse($product->expire_date)->format('M-d-Y h:i A')); ?>

                                                        (<?php echo e(\Carbon\Carbon::now()->diffForHumans($product->expire_date, [
                                                            'syntax' => \Carbon\CarbonInterface::DIFF_ABSOLUTE,
                                                            'parts' => 3, // Limit to days, hours, and minutes
                                                        ])); ?>)
                                                    <?php else: ?>
                                                        Expired
                                                    <?php endif; ?>
                                                </dd>

                                            <?php endif; ?>
                                        </dl>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="tf-product-info-variant-picker">
                            <div class="variant-picker-item">
                                <div class="variant-picker-label body-text">
                                    Size:
                                </div>
                                <div class="variant-picker-values">
                                    <label class="style-text" for="values-s" data-value="S">
                                        <div class="body-title-2">S</div>
                                    </label>

                                </div>
                            </div>
                        </div>

                        

                    </div>
                </div>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>

    <script src="<?php echo e(asset('assets/js/zoom.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/swiper-bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/carousel.js')); ?>"></script>

<?php $__env->stopPush(); ?>


<?php echo $__env->make('backend.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\Herd\fahad\resources\views/backend/layouts/product/show.blade.php ENDPATH**/ ?>