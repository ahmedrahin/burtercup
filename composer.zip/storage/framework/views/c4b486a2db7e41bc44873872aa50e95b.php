<div class="bottom-page">
    <div class="body-text">Copyright © 2025.</div>

</div>
<?php /**PATH C:\Users\USER\Herd\fahad\resources\views/backend/partials/footer.blade.php ENDPATH**/ ?>