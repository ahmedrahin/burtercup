<?php
    // $systemSetting = App\Models\SystemSetting::first();
?>

<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/animate.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/animation.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/bootstrap.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/bootstrap-select.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/style.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/custom.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/font/fonts.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/icon/style.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/toastify.css')); ?>"/>
<link rel="stylesheet" type="text/css" href="https://jeremyfagis.github.io/dropify/dist/css/dropify.min.css">
<link href="https://cdn.jsdelivr.net/npm/sweetalert2@11.4.18/dist/sweetalert2.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/magnific-popup.min.css">
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
<?php echo $__env->yieldPushContent('styles'); ?>
<?php /**PATH C:\Users\USER\Herd\fahad\resources\views/backend/partials/style.blade.php ENDPATH**/ ?>