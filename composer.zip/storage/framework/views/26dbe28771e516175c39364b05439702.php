<?php $__env->startSection('title', 'Order Details ' . $data->order_id); ?>

<?php $__env->startPush('styles'); ?>

    <style>
        .table-order-detail .name {
            text-align: center;
        }
        .table-order-detail .product-name {
            text-align: left !important;
        }
        .total {
            text-align: right !important;
        }
        .wg-order-detail .right{
            width: 380px !important;
        }
    </style>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-content-wrap">
        <div class="flex items-center flex-wrap justify-between gap20 mb-27">
            <h3><?php echo $__env->yieldContent('title'); ?></h3>
            <ul class="breadcrumbs flex items-center flex-wrap justify-start gap10">
                <li>
                    <a href="<?php echo e(route('dashboard')); ?>"><div class="text-tiny">Dashboard</div></a>
                </li>
                <li><i class="icon-chevron-right"></i></li>
                <li>
                    <a href="<?php echo e(route('order.index')); ?>"><div class="text-tiny">Order Details</div></a>
                </li>
                <li><i class="icon-chevron-right"></i></li>
                <li><div class="text-tiny"><?php echo $__env->yieldContent('title'); ?></div></li>
            </ul>
        </div>
    </div>

    <div class="wg-order-detail">
        <div class="left flex-grow">
            <div class="wg-box mb-20">
                <div class="wg-table table-order-detail">
                    <ul class="table-title flex items-center justify-between gap20 mb-24">
                        <li>
                            <div class="body-title">All item</div>
                        </li>
                        <li>
                            <div class="dropdown default">
                                <ul class="dropdown-menu">
                                    <li>
                                        <a href="javascript:void(0);">Name</a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0);">Quantity</a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0);">Price</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                    </ul>
                    <ul class="flex flex-column">
                        <!-- Header Row -->
                        <li class="product-item gap14">

                            <div class="flex items-center justify-between gap40 flex-grow">
                                <div class="name product-name">
                                    <div class="body-title-2 font-bold">Product</div>
                                </div>
                                <div class="name">
                                    <div class="body-title-2 font-bold">Quantity</div>
                                </div>
                                <div class="name">
                                    <div class="body-title-2 font-bold">Price</div>
                                </div>
                                <div class="name total">
                                    <div class="body-title-2 font-bold">Total</div>
                                </div>
                            </div>
                        </li>

                        <!-- Order Items -->
                        <?php $__currentLoopData = $data->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="product-item gap14">
                                <div class="image no-bg">
                                    <img src="<?php echo e(asset($item->product->thumb_image)); ?>" alt="">
                                </div>
                                <div class="flex items-center justify-between gap40 flex-grow">
                                    <div class="name product-name">
                                        <a href="<?php echo e(route('product.show', $item->product->id)); ?>" class="body-title-2"><?php echo e($item->product->name); ?></a>
                                    </div>
                                    <div class="name">
                                        <div class="body-title-2"><?php echo e($item->quantity); ?></div>
                                    </div>
                                    <div class="name">
                                        <div class="body-title-2">$<?php echo e($item->price); ?></div>
                                    </div>
                                    <div class="name total">
                                        <div class="body-title-2">$<?php echo e(number_format($item->price * $item->quantity,2)); ?></div>
                                    </div>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>

                </div>
            </div>
            <div class="wg-box">
                <div class="wg-table table-cart-totals">
                    <ul class="table-title flex mb-24">
                        <li>
                            <div class="body-title">Cart Totals</div>
                        </li>
                        <li>
                            <div class="body-title">Price</div>
                        </li>
                    </ul>
                    <ul class="flex flex-column gap14">
                        <li class="cart-totals-item">
                            <span class="body-text">Subtotal:</span>
                            <span class="body-title-2">$<?php echo e(number_format($data->subtotal,2)); ?></span>
                        </li>

                        <li class="divider"></li>
                        <?php if( $data->coupon_discount ): ?>
                            <li class="cart-totals-item">
                                <span class="body-text">Coupon Discount:</span>
                                <span class="body-title-2">(- $<?php echo e($data->coupon_discount); ?>)</span>
                            </li>
                        <?php endif; ?>

                        <li class="cart-totals-item">
                            <span class="body-title">Grand Total:</span>
                            <span class="body-title tf-color-1">$<?php echo e(number_format($data->grand_total,2)); ?></span>
                        </li>

                    </ul>
                </div>


                <?php if( $data->note ): ?>
                    
                    
                <?php endif; ?>
            </div>
        </div>

        <div class="right">
            <div class="wg-box mb-20 gap10">
                <div class="body-title">Summary</div>
                <div class="summary-item">
                    <div class="body-text">Order ID</div>
                    <div class="body-title-2">#<?php echo e($data->order_id); ?></div>
                </div>
                <div class="summary-item">
                    <div class="body-text">Order Date</div>
                    <div class="body-title-2"><?php echo e(Carbon\Carbon::parse($data->order_date)->format('d M, Y - (h:i A)')); ?></div>
                </div>
                <div class="summary-item">
                    <div class="body-text">Order Time</div>
                    <div class="body-title-2"><?php echo e(\Carbon\Carbon::parse($data->order_date)->diffForHumans()); ?></div>
                </div>
                <?php if( $data->coupon_discount ): ?>
                    <div class="summary-item">
                        <div class="body-text">Coupon</div>
                        <div class="body-title-2"><?php echo e($data->cupon_code); ?></div>
                    </div>
                <?php endif; ?>
                <div class="summary-item">
                    <div class="body-text">Transaction_id</div>
                    <div class="body-title-2"><?php echo e($data->transaction_id); ?></div>
                </div>
                <div class="summary-item">
                    <div class="body-text">Total</div>
                    <div class="body-title-2 tf-color-1">$<?php echo e(number_format($data->grand_total,2)); ?></div>
                </div>
            </div>

            <div class="wg-box mb-20 gap10">
                <div class="body-title">Customer Information</div>
                <div class="summary-item">
                    <div class="body-text">Name</div>
                    <div class="body-title-2 ">
                        <a href="<?php echo e(route('user.show',$data->user->id)); ?>" class="text-primary">
                            <?php echo e($data->user->name); ?>

                        </a>
                    </div>
                </div>
                <div class="summary-item">
                    <div class="body-text">Email</div>
                    <div class="body-title-2"><?php echo e($data->user->email); ?></div>
                </div>
                <div class="summary-item">
                    <div class="body-text">Phone</div>
                    <div class="body-title-2"><?php echo e($data->phone); ?></div>
                </div>
            </div>

            <div class="wg-box mb-20 gap10">
                <div class="body-title">Shipping Address</div>
                <div class="body-text">
                    <?php echo e($data->shipping_address); ?>

                </div>
            </div>

            <div class="wg-box mb-20 gap10">
                <div class="body-title">Payment Method</div>
                <div class="body-text"><?php echo e($data->payment_method); ?></div>
            </div>
            <div class="wg-box gap10">
                <div class="body-title">Expected Date Of Delivery</div>
                <div class="body-title-2 tf-color-2">20 Nov 2023</div>
                <a class="tf-button style-1 w-full" href="oder-tracking.html"><i class="icon-truck"></i>Track order</a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function () {
            var orderId = "<?php echo e($data->id); ?>";

            $.ajax({
                url: "<?php echo e(route('view.order')); ?>",
                method: "POST",
                data: {
                    _token: "<?php echo e(csrf_token()); ?>",
                    order_id: orderId
                },
                success: function (response) {
                    console.log(response.message);
                },
                error: function (xhr) {
                    console.log(xhr.responseText);
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('backend.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\Herd\fahad\resources\views/backend/layouts/order/details.blade.php ENDPATH**/ ?>