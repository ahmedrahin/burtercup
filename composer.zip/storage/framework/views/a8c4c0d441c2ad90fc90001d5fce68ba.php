<?php $__env->startSection('title', $data->name . ' Details'); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .user-detail-box {
        background: #fff;
        border-radius: 10px;
        padding: 30px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }
    .user-detail-row {
        display: flex;
        justify-content: space-between;
        margin-bottom: 15px;
        border-bottom: 1px dashed #ddd;
        padding-bottom: 10px;
    }
    .label {
        font-weight: bold;
        color: #555;
        width: 30%;
        font-size: 13px;
    }
    .value {
        color: #333;
        width: 65%;
        text-align: right;
        font-size: 13px;
    }
    .user-img {
        width: 120px;
        display: block;
        margin: auto;
        margin-bottom: 20px;
        border-radius: 50%;
        border: 1px solid #eee;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="main-content-wrap">
    <div class="flex items-center flex-wrap justify-between gap20 mb-27">
        <h3><?php echo $__env->yieldContent('title'); ?></h3>
        <ul class="breadcrumbs flex items-center flex-wrap justify-start gap10">
            <li>
                <a href="<?php echo e(route('dashboard')); ?>"><div class="text-tiny">Dashboard</div></a>
            </li>
            <li><i class="icon-chevron-right"></i></li>
            <li><div class="text-tiny"><?php echo $__env->yieldContent('title'); ?></div></li>
        </ul>
    </div>

    <div class="wg-box user-detail-box">

        <img src="<?php echo e(asset($data->avatar ?? 'user.png')); ?>" class="user-img">

        <div class="user-detail-row">
            <div class="label">Full Name:</div>
            <div class="value"><?php echo e($data->name); ?> <?php echo e($data->last_name); ?></div>
        </div>

        <div class="user-detail-row">
            <div class="label">Email:</div>
            <div class="value">
                <a href="mailto:<?php echo e($data->email); ?>"><?php echo e($data->email); ?></a>
            </div>
        </div>

        <div class="user-detail-row">
            <div class="label">Date of Birth:</div>
            <div class="value"><?php echo e($data->date_of_birth ?? '-'); ?></div>
        </div>

        <div class="user-detail-row">
            <div class="label">Gender:</div>
            <div class="value"><?php echo e(ucfirst($data->gender ?? '-')); ?></div>
        </div>

        <div class="user-detail-row">
            <div class="label">City:</div>
            <div class="value"><?php echo e($data->city ?? '-'); ?></div>
        </div>

        <div class="user-detail-row">
            <div class="label">Country:</div>
            <div class="value"><?php echo e($data->country ?? '-'); ?></div>
        </div>

        <div class="user-detail-row">
            <div class="label">Age:</div>
            <div class="value"><?php echo e($data->age ?? '-'); ?></div>
        </div>

        <div class="user-detail-row">
            <div class="label">Coins:</div>
            <div class="value text-success"><?php echo e($data->coins); ?></div>
        </div>

        <div class="user-detail-row">
            <div class="label">Selected Categories:</div>
            <div class="value text-right">
                <?php
                    $categories = is_array($data->categories) ? $data->categories : json_decode($data->categories, true);
                ?>


                <?php if(is_array($categories)): ?>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class="badge bg-primary">
                            <?php echo e(ucfirst($category)); ?>

                        </span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <span class="text-gray-400">No category selected</span>
                <?php endif; ?>
            </div>
        </div>


        <div class="user-detail-row">
            <div class="label">Status:</div>
            <div class="value">
                <span class="badge <?php echo e($data->status === 'active' ? 'bg-success' : 'bg-danger'); ?>">
                    <?php echo e(ucfirst($data->status)); ?>

                </span>
            </div>
        </div>

        <div class="user-detail-row">
            <div class="label">Email Verified:</div>
            <div class="value">
                <span class="badge <?php echo e($data->email_verified_at ? 'bg-success' : 'bg-danger'); ?>">
                    <?php echo e($data->email_verified_at ? 'verified' : 'unverified'); ?>

                </span>
            </div>
        </div>


    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<!-- Add any JS if needed -->
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\Herd\burtercup\resources\views/backend/layouts/user/details.blade.php ENDPATH**/ ?>