<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startPush('styles'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    

    

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/raphael/2.3.0/raphael.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>
    <script src="<?php echo e(asset('assets/js/jvectormap-1.2.2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jvectormap-us-lcc.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jvectormap.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/morris.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/js/apexcharts/apexcharts.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/apexcharts/line-chart-1.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/apexcharts/line-chart-2.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/apexcharts/line-chart-3.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/apexcharts/line-chart-4.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/apexcharts/line-chart-8.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/apexcharts/line-chart-9.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/apexcharts/line-chart-10.js')); ?>"></script>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            Morris.Donut({
                element: 'morris-donut-1',
                data: [
                    { label: "Male", value: <?php echo e($malePercent); ?> },
                    { label: "Female", value: <?php echo e($femalePercent); ?> }
                ],
                colors: ['#4a90e2', '#f06292'],
                formatter: function (y) {
                    return y + "%";
                }
            });
        });
    </script>

    <script>
        new Morris.Donut({
            element: 'country-donut-chart',
            data: [
                <?php $__currentLoopData = $countryStats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    { label: "<?php echo e($country['country']); ?>", value: <?php echo e($country['count']); ?> },
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ],
            colors: ['#4a90e2', '#f06292', '#7ed6df', '#f39c12', '#6ab04c']
        });
    </script>


    <script>
        new Morris.Donut({
            element: 'age-donut-chart',
            data: [
                <?php $__currentLoopData = $ageStats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $age): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    { label: "<?php echo e($age['range']); ?>", value: <?php echo e($age['count']); ?> },
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ],
            colors: ['#4a90e2', '#f06292', '#7ed6df', '#f39c12', '#6ab04c'],
            formatter: function (y) {
                return y + " Users";
            }
        });
    </script>

    <script>
        new Morris.Donut({
            element: 'category-donut-chart',
            data: [
                <?php $__currentLoopData = $categoryStats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    { label: "<?php echo e($category['category']); ?>", value: <?php echo e($category['count']); ?> },
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ],
            colors: ['#4a90e2', '#f06292', '#7ed6df', '#f39c12', '#6ab04c', '#9b59b6', '#1abc9c', '#e74c3c'],
            formatter: function (y) {
                return y + " Users";
            }
        });
    </script>


<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\Herd\burtercup\resources\views/backend/layouts/dashboard.blade.php ENDPATH**/ ?>