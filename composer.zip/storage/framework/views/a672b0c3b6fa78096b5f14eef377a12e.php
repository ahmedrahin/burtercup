<?php $__env->startSection('title', 'Add New Coupon'); ?>

<?php $__env->startPush('styles'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    <div class="main-content-wrap">
        <div class="flex items-center flex-wrap justify-between gap20 mb-27">
            <h3><?php echo $__env->yieldContent('title'); ?></h3>
            <ul class="breadcrumbs flex items-center flex-wrap justify-start gap10">
                <li>
                    <a href="<?php echo e(route('dashboard')); ?>"><div class="text-tiny">Dashboard</div></a>
                </li>
                <li>
                    <i class="icon-chevron-right"></i>
                </li>
                <li>
                    <a href="<?php echo e(route('coupon.index')); ?>"><div class="text-tiny">Coupon</div></a>
                </li>
                <li>
                    <i class="icon-chevron-right"></i>
                </li>
                <li>
                    <div class="text-tiny"><?php echo $__env->yieldContent('title'); ?></div>
                </li>
            </ul>
        </div>

        <!-- add-new-user -->
        <form class="form-add-new-user form-style-2" id="addform" method="POST" >
            <?php echo csrf_field(); ?>
            <div class="wg-box">

                <div class="row g-5 right flex-grow">

                    <div class="col-md-6">
                        <fieldset class="name mb-14">
                            <div class="body-title mb-10">Coupon Code <span class="required text-danger" style="font-size: 16px;">*</span> </div>
                            <input class="flex-grow" type="text" placeholder="Enter code" name="code" >
                            <div class="error text-danger"></div>
                        </fieldset>

                        <fieldset class="name mb-14">
                            <div class="body-title mb-10">Min Purchase Amount</div>
                            <input class="flex-grow" type="text" placeholder="Enter amount" name="min_purchase_amount" >
                            <div class="error text-danger"></div>
                        </fieldset>

                        <fieldset class="name mb-14">
                            <div class="body-title mb-10">Usage Limit</div>
                            <input class="flex-grow" type="text" placeholder="ex: 3" name="usage_limit" >
                            <div class="error text-danger"></div>
                        </fieldset>

                        <fieldset class="name mb-14">
                            <div class="body-title mb-10">Used User</div>
                            <input class="flex-grow" type="text" placeholder="ex: 3" name="used" >
                            <div class="error text-danger"></div>
                        </fieldset>
                    </div>

                    <div class="col-md-6">
                        <fieldset class="name mb-14">
                            <div class="body-title mb-10">Discount Amount <span class="required text-danger" style="font-size: 16px;">*</span> </div>
                            <input class="flex-grow" type="text" placeholder="Enter amount" name="discount_amount" >
                            <div class="error text-danger"></div>
                        </fieldset>

                        <fieldset class="name mb-14">
                            <div class="body-title mb-10">Discount Type <span class="required text-danger" style="font-size: 16px;">*</span> </div>
                            <select name="discount_type" id="discount_type">
                                <option value="percentage">Percentage</option>
                                <option value="fixed">Fixed</option>
                            </select>
                            <div class="error text-danger"></div>
                        </fieldset>

                        <fieldset class="name mb-14">
                            <div class="body-title mb-10">Start At <span class="required text-danger" style="font-size: 16px;">*</span> </div>
                            <div style="position: relative;">
                                <input type="date" name="start_at" id="start_at"  placeholder="Select Start Date & Time" autocomplete="off">
                                <div class="error text-danger"></div>
                                <i class="icon-calendar"></i>
                            </div>
                        </fieldset>

                        <fieldset class="name mb-14">
                            <div class="body-title mb-10">Expire Date <span class="required text-danger" style="font-size: 16px;">*</span> </div>
                            <div style="position: relative;">
                                <input type="date" name="expire_date" id="coupon_expire_date"  placeholder="Select Expire Date & Time" autocomplete="off">
                                <div class="error text-danger"></div>
                                <i class="icon-calendar"></i>
                            </div>
                        </fieldset>
                    </div>

                </div>
            </div>

            <div class="bot " style="justify-content:right;">
                <button class="tf-button w180 btn-add" type="submit" id="submitBtn">
                    <span class="btn-text">Save</span>
                    <span class="loader spinner-border spinner-border-sm hidden" role="status" aria-hidden="true"></span>
                </button>
            </div>

        </form>

        <!-- /add-new-user -->
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('.dropify').dropify();

            $('#addform').on('submit', function(e) {
                e.preventDefault();
                $('.error').html('');

                var formData = new FormData(this);

                // Show loader
                $('#submitBtn .btn-text').text('Saving...');
                $('#submitBtn .loader').removeClass('hidden');
                $('#submitBtn').prop('disabled', true);

                $.ajax({
                    url: "<?php echo e(route('coupon.store')); ?>",
                    method: "POST",
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        // Reset button
                        $('#submitBtn .btn-text').text('Save');
                        $('#submitBtn .loader').addClass('hidden');
                        $('#submitBtn').prop('disabled', false);

                        if (response.success) {
                            $('.error_border').removeClass('error_border');
                            $('.error').text('');
                            ajaxMessage(response.message, 'success');
                            $('#addform')[0].reset();
                        }
                    },
                    error: function(xhr) {
                        $('#submitBtn .btn-text').text('Save');
                        $('#submitBtn .loader').addClass('hidden');
                        $('#submitBtn').prop('disabled', false);

                        if (xhr.status === 422) {
                            $('.error-border').removeClass('error-border');
                            let errors = xhr.responseJSON.errors;
                            $.each(errors, function(key, val) {
                                let inputField = $('[name="' + key + '"]');
                                inputField.siblings('.error').text(val[0]);
                                inputField.addClass('error_border');
                            });
                        } else {
                            alert('Something went wrong!');
                        }
                    }

                });
            });
        });
    </script>


    <script>
        flatpickr("#start_at", {
            enableTime: true,
            dateFormat: "Y-m-d h:i K",
            time_24hr: false,
            allowInput: true,
        });

        flatpickr("#coupon_expire_date", {
            enableTime: true,
            dateFormat: "Y-m-d h:i K",
            time_24hr: false,
            allowInput: true,
        });
    </script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('backend.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\Herd\fahad\resources\views/backend/layouts/coupon/create.blade.php ENDPATH**/ ?>