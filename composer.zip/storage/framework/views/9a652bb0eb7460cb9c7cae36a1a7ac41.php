<div class="section-menu-left">
    <div class="box-logo">
        <a href="" id="site-logo-inner">
            <img class="" id="logo_header" alt="" src="<?php echo e(asset('assets/images/logo/logo.png')); ?>" data-light="<?php echo e(asset('assets/images/logo/logo.png')); ?>" data-dark="<?php echo e(asset('assets/images/logo/logo-dark.png')); ?>" >
        </a>
        <div class="button-show-hide">
            <i class="icon-menu-left"></i>
        </div>
    </div>
    <div class="section-menu-left-wrap">
        <div class="center">
            <div class="center-item">
                <ul class="menu-list">
                    <li class="menu-item <?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>">
                        <a href="javascript:void(0);" class="menu-item-button">
                            <div class="icon">
                                <i class="icon-grid"></i>
                            </div>
                            <div class="text">Dashboard</div>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="center-item">
                <div class="center-heading">Admin Management</div>
                <ul class="menu-list">
                    <li class="menu-item has-children <?php echo e(request()->routeIs('admin*') ? 'active' : ''); ?>">
                        <a href="javascript:void(0);" class="menu-item-button">
                            <div class="icon"><i class="icon-user-check"></i></div>
                            <div class="text">Admin Details</div>
                        </a>
                        <ul class="sub-menu">
                            <li class="sub-menu-item">
                                <a href="" class="<?php echo e(request()->routeIs('admin.index') ? 'active' : ''); ?>">
                                    <div class="text">Admin List</div>
                                </a>
                            </li>
                            <li class="sub-menu-item">
                                <a href="<?php echo e(route('admin.create')); ?>" class="<?php echo e(request()->routeIs('admin.create') ? 'active' : ''); ?>">
                                    <div class="text">Create new Admin</div>
                                </a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>

        </div>

    </div>
</div>
<?php /**PATH C:\Users\USER\Herd\azad\resources\views/backend/partials/sidebar.blade.php ENDPATH**/ ?>