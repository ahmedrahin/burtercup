<div class="row variant-box">
    
    <div class="col-md-4">
        <div class="wg-box">
            <div class="d-flex align-items-center justify-between mb-4 top">
                <h3>Select Size</h3>
            </div>
            <div class="right flex-grow">
                <div class="row gx-3 gy-1">
                    <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $isChecked = in_array($size->size_value, $selectedSizes); ?>
                        <div class="col-sm-6 col-md-4 col-lg-3">
                            <label class="position-relative bg-light rounded-3 border shadow-sm p-3 text-center size-card hover-shadow d-block selectable-card <?php echo e($isChecked ? 'active' : ''); ?>">
                                <input type="checkbox"
                                       name="sizes[]"
                                       value="<?php echo e($size->size_value); ?>"
                                       class="d-none toggle-check"
                                       <?php echo e($isChecked ? 'checked' : ''); ?>>
                                <h5 class="mb-0 text-primary"><?php echo e($size->size_value); ?></h5>
                            </label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>

    
    <div class="col-md-4">
        <div class="wg-box">
            <div class="d-flex align-items-center justify-between mb-4 top">
                <h3>Select Color</h3>
            </div>
            <div class="right flex-grow">
                <div class="row gx-3 gy-1">
                    <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $isChecked = in_array($color->color_value, $selectedColors); ?>
                        <div class="col-sm-6 col-md-4 col-lg-3">
                            <label class="position-relative bg-light rounded-3 border shadow-sm p-3 text-center size-card hover-shadow d-block selectable-card <?php echo e($isChecked ? 'active' : ''); ?>">
                                <input type="checkbox"
                                       name="colors[]"
                                       value="<?php echo e($color->color_value); ?>"
                                       class="d-none toggle-check"
                                       <?php echo e($isChecked ? 'checked' : ''); ?>>
                                <h5 class="mb-0 text-primary"><?php echo e($color->color_value); ?></h5>
                            </label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>


<?php /**PATH C:\Users\USER\Herd\fahad\resources\views/backend/layouts/product/edit-component/product-variant.blade.php ENDPATH**/ ?>