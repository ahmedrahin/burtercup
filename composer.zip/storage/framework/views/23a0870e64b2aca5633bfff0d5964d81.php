<div class="bottom-page">
    <div class="body-text">Copyright © 2024 Remos. Design with</div>
    <i class="icon-heart"></i>
    <div class="body-text">by <a href="https://themeforest.net/user/themesflat/portfolio">Themesflat</a> All rights reserved.</div>
</div><?php /**PATH C:\Users\USER\Herd\azad\resources\views/backend/partials/footer.blade.php ENDPATH**/ ?>