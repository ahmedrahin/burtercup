<?php

namespace App\Http\Controllers\Web\Backend\Product;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;


class WishlistController extends Controller
{

}
